Restaurant Table Booking System - VS Code Project

How to run:
1. Download and extract restaurant-booking-system.zip
2. Open VS Code
3. Click File > Open Folder
4. Select restaurant-booking-system folder
5. Open index.html
6. Right click > Open with Live Server
   OR double click index.html directly

User side:
1. Select date and time
2. Choose number of guests
3. Choose table size
4. Enter name, phone and email
5. Click Submit Booking

Admin side:
1. Open admin.html or click Admin menu
2. Username: admin
3. Password: 1234
4. View all submitted bookings
5. Delete booking if needed

Note:
This simple version stores data in browser localStorage.
For final explanation, you can say the same design can be connected with Firebase/MySQL backend.
